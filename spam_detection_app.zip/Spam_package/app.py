import numpy as np
from flask import Flask, request, jsonify, render_template
import pickle

# Create app
app = Flask(__name__)

# Assign and load our model
model = pickle.load(open("emails_classifier.pkl", "rb"))

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])  
def predict():
    x = request.form['text']  
    input_data = np.array([x])  
    predictions = model.predict(input_data)
    predictions_prob = model.predict_proba(input_data)

    if predictions[0] == 0:  
        clase = 'Ham'
    else:
        clase = 'Spam'

    probability = predictions_prob[0][predictions[0]]  

    return render_template("index.html", prediction_text="The model predicts that this text comes from a " + clase + " email with a probability of " + str(round(100 * probability, 2)) + "%")

if __name__ == "__main__":
    app.run(debug=True)
